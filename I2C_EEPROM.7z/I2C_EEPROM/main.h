//PUT INCLUDE GUARDS HERE


//void weeprom (char page, char address, char datum);
//char reeprom (char page, char address);
//char read (char readcmd);
void outs (char datum);
void out (char datum);
char in (void);
void stop (void);
