//**********************************************************************
//* Function Name: void weeprom (char page, char address, char datum)
//**********************************************************************
//* Function Description: write routine for I2C EEPROM
//**********************************************************************
//* Input parameters:
//* - char page: number of 256 bytes block to use
//* - char address: position inside the 256 bytes block
//* - char datum: 1 byte data to write
//**********************************************************************
//* Output parameters: NONE
//**********************************************************************
/// Notes: NONE
//**********************************************************************
#include "I2C_Functions.h"
#include "mcs51/at89c51ed2.h"
//#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "uart.h"

#define SDA (P1_6)
#define SCK (P1_7)
//bit SCK=P1_7;

uint16_t num;
uint16_t block;
uint16_t byte_addr;
void weeprom (char page, char address, char datum)
{
	char WRCMD; // auxiliary storage to build the write command
	page = page << (1); // move A0, A1 & A2 to their positions
	page = page & (0xFE); // clear r/w bit
	WRCMD = page | (0xA0); // build the write command
	outs (WRCMD); // send the write command with start condition
	out (address); // send address
	out (datum); // send data
	stop (); // send stop condition
}



//delay function for proper synchronization
void delay(uint16_t val)
{
    while(val>0)
    {
        val--;
    }
}
//**********************************************************************
//* Function Name: char reeprom (char page, char address)
//**********************************************************************
//* Function Description: read routine for I2C EEPROM
//**********************************************************************
//* Input parameters:
//* - char page: number of 256 bytes block to use
//* - char address: position inside the 256 bytes block
//**********************************************************************
//* Output parameters:
//* - char with the data from memory
//**********************************************************************
/// Notes: NONE
//**********************************************************************
char reeprom (char page, char address)
{
	char aux; // auxiliary storage
	char WRCMD; // aux. storage for the write command (to send the add.)
	aux = page; // preparing the write command
	aux = aux << (1); // move A0, A1 & A2 to their positions
	aux = aux & (0xFE); // clear r/w bit
	WRCMD = aux | (0xA0); // build the write command
	outs (WRCMD); // send the write command with start condition
	out (address); // send address
	aux = read (WRCMD); // send read command and receive data
	return (aux); // return solicited data
}

//**********************************************************************
//* Function Name: char read (char readcmd)
//**********************************************************************
//* Function Description: reads 1 byte from current memory position
//**********************************************************************
//* Input parameters:
//* - char readcmd: read command byte with A0, A1 & A2 embedded
//**********************************************************************
//* Output parameters:
//* - char with current address data
//**********************************************************************
/// Notes: NONE
//**********************************************************************
char read (char readcmd)
{
	char RDCMD; // auxiliary storage to build the read command
	char aux; // auxiliary storage
	RDCMD = readcmd | 0x01; // set r/w bit
	outs (RDCMD); // send read command with start condition
	aux = in(); // read current position
	stop (); // send stop condition
	return (aux); // return current position data
}

//**********************************************************************
//* Function Name: void outs (char datum)
//**********************************************************************
//* Function Description: sends to memory the input parameter with a
//*                       start condition
//**********************************************************************
//* Input parameters:
//* - char datum: data byte to send to the memory
//**********************************************************************
//* Output parameters: NONE
//**********************************************************************
/// Notes: NONE
//**********************************************************************
void outs (char datum)
{
	char i; // index
	char aux; // auxiliary storage
	SDA = 1; // set port pin SDA to insure data is HI
	SCK = 1; // set port pin SCK to insure clock is HI
__asm
	nop
	nop
	nop
	nop
	nop
__endasm;
	SDA = 0; // start condition, data = 0
__asm
	nop
	nop
	nop
	nop
	nop
__endasm;

	SCK = 0; // clock = 0
/*
The data on the line must be changed only when clock is low
*/
	for (i = 0; i < 8; i++) // bit shifting cycle
	{
		aux = datum & 0x80; // check MSB bit
		if (aux == 0) // MSB = 0
			SDA = 0; // then SDA = 0
		else
			SDA = 1; // else MSB =1, then SDA = 1
		SCK = 1; // clock = 1

//Why is SCK being toggled here?
//perhaps so that noise cannot be confused as data
// or maybe to produce the extra clock pulse at the end of the loop
__asm
		nop
		nop
		nop
		nop
		nop
__endasm;

//Why is SCK being toggled here?

		SCK = 0; // clock = 0
		datum = datum << 1; // rotate for next bit
	}

	SDA = 1; // set port pin for ack
//The slave will pull down the SDA to generate an ACK, however the SDA is already pulled-up by a resistor?
__asm
	nop
	nop
	nop
__endasm;
	SCK = 1; // clock ack
__asm
	nop
	nop
	nop
	nop
	nop
__endasm;
	SCK = 0; // clock = 0
}


//**********************************************************************
//* Function Name: void out (char datum)
//**********************************************************************
//* Function Description: sends to memory the input parameter without a
//*                       start condition
//**********************************************************************
//* Input parameters:
//* - char datum: data byte to send to the memory
//**********************************************************************
//* Output parameters: NONE
//**********************************************************************
/// Notes: NONE
//**********************************************************************
void out (char datum)
{
	char i; // index
	char aux; // auxiliary storage
	for (i = 0; i < 8; i++) // bit shifting cycle
	{
		aux = datum & 0x80; // check MSB bit
		if (aux == 0) // MSB = 0
			SDA = 0; // then SDA = 0
		else
			SDA = 1; // else MSB = 1, the SDA = 1
		SCK = 1; // clock = 1
__asm
		nop
		nop
		nop
		nop
		nop
__endasm;
		SCK = 0; // clock = 0
		datum = datum << 1; // rotate for next bit
	}
	SDA = 1; // set port pin for ack
__asm
	nop
	nop
	nop
__endasm;
	SCK = 1; // clock ack
__asm
	nop
	nop
	nop
	nop
	nop
__endasm;
	SCK = 0; // clock = 0
}


//**********************************************************************
//* Function Name: char in (void)
//**********************************************************************
//* Function Description: receives a byte from memory
//**********************************************************************
//* Input parameters: NONE
//**********************************************************************
//* Output parameters:
//* - char with the byte received from memory
//**********************************************************************
/// Notes: NONE
//**********************************************************************
char in (void)
{
	char i; // index
	char aux = 0; // auxiliary storage
	SDA = 1; // insure port pin = 1 for input
	for (i = 0; i < 8; i++) // bit shifting cycle
	{
		SCK = 0; // clock = 0
__asm
		nop
		nop
		nop
		nop
		nop
		nop
__endasm;
		SCK = 1; // clock = 1
		aux = aux << 1; // load bit position
		if (SDA) // check SDA data from port pin
			aux = aux | 0x01; // if port pin = 1, set LSB (bit position)
		else
			aux = aux & 0xFE; // else port pin = ,clear LSB (bit position)
	}
	SCK = 0; // clock = 0
	return (aux); // return data received
}


//**********************************************************************
//* Function Name: void stop (void)
//**********************************************************************
//* Function Description: send stop condition
//**********************************************************************
//* Input parameters: NONE
//**********************************************************************
//* Output parameters: NONE
//**********************************************************************
/// Notes: NONE
//**********************************************************************
void stop (void)
{
	SDA = 0; // stop condition, data = 0
__asm
	nop
	nop
	nop
	nop
	nop
__endasm;
	SCK = 1; // clock = 1
__asm
	nop
	nop
	nop
	nop
	nop
__endasm;
	SDA = 1; // data = 1
}

//function to provide the start bit condition
void start(void)
{
    SDA = 1; // set port pin SDA to insure data is HI
	SCK = 1; // set port pin SCK to insure clock is HI
__asm
	nop
	nop
	nop
	nop
	nop
__endasm;
	SDA = 0; // start condition, data = 0
__asm
	nop
	nop
	nop
	nop
	nop
__endasm;
	SCK = 0;
}

//function to reset the I2C bus.
void eereset()
{
    //initiate with start bit
    start();

	///9 bits of '1'
    char i; // index
	uint32_t aux; // auxiliary storage
	uint32_t datum = 0x1FF;
	for (i = 0; i < 9; i++) // bit shifting cycle
	{
		aux = datum & 0x100; // check MSB bit
		if (aux == 0) // MSB = 0
			SDA = 0; // then SDA = 0
		else
			SDA = 1; // else MSB = 1, the SDA = 1
		SCK = 1; // clock = 1
__asm
		nop
		nop
		nop
		nop
		nop
__endasm;
		SCK = 0; // clock = 0
		datum = datum << 1; // rotate for next bit
	}
	//start bit again
    start();
	stop();
}

void Seq_read(char page,char faddress,char laddress)
{
  char difference = laddress - faddress;
  volatile char counter = 0;
  //counter = 0;
    char aux; // auxiliary storage
    char WRCMD; // aux. storage for the write command (to send the add.)
    aux = page; // preparing the write command
    aux = aux << 1; // move A0, A1 & A2 to their positions
    aux = aux & 0xFE; // clear r/w bit
    WRCMD = aux | 0xA0; // build the write command
   //Start
   //start();
   // Send word address
    outs(WRCMD);
    // ack
    out(faddress); // send address
   // ack
   // Repeated Start
    start();
   // Issue Control command again but with R/W bit = 1
    aux = page; // preparing the write command
    aux = aux << 1; // move A0, A1 & A2 to their positions
    aux = aux & 0xFE; // clear r/w bit
    WRCMD = aux | 0xA1; // Make R/W = 1
   ///There is another start in outs
    out(WRCMD); // send the write command with start condition
   /// Pulling up SCK
    //delay(1000);
    // Accept data from EEPROM
    // for(counter = 0;counter++;counter<difference)
    // difference = last address - first address
    printf_tiny("Before For Loop\n\r");
    printf_tiny("%d\n\r",difference);
    printf_tiny("%d\n\r",counter);
    //for(counter = 0;counter++;counter<=difference)
    while(counter <= difference)
   {
       printf_tiny("Inside For Loop\n\r");
       printf_tiny("%d\n\r",counter);
       aux = in();
       SDA = 0; // set port pin for ack
       //The slave will pull down the SDA to generate an ACK, however the SDA is already pulled-up by a resistor?
__asm
        nop
        nop
        nop
__endasm;
        SCK = 1; // clock ack
__asm
        nop
        nop
        nop
        nop
        nop
__endasm;
        SCK = 0; // clock = 0
        SDA = 1;
       printf_tiny("%x\n\r",aux);
       counter++;
   }
   //??DO I NEED TO PUT A NACK HERE??
   stop();
}



//the main function to do function calls
void main()
{
//Working below code lines
//    weeprom(0x00,0xB1,0x11);
//    delay(1000);
//    weeprom(0x00,0xB2,0x22);
//    delay(1000);
//    weeprom(0x00,0xB3,0x33);
//    delay(1000);
//    weeprom(0x00,0xB4,0x44);
//    delay(1000);
    //char temp = reeprom(0x00,0xF0);
    //printf_tiny("%x",temp);
    //delay(1000);
    //eereset();
    //delay(1000);

    printf_tiny("\n\rEnter the address to start read from:\n\r");
    getNum();

    //Seq_read(0x00,0xB1,0xB4);
    //delay(1000);
    while(1);
}
