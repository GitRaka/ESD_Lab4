/*
 */

#include <mcs51/8051.h>
#inc
// Port pin declaration
extern volatile bit SCK;
extern volatile bit SDA;

void weeprom (char page, char address, char datum);
void outs (char datum);
void out (char datum);

void weeprom (char page, char address, char datum)
{
	char WRCMD; // auxiliary storage to build the write command
	page = page << 1; // move A0, A1 & A2 to their positions
	page = page & 0xFE; // clear r/w bit
	WRCMD = page | 0xA0; // build the write command
	outs (WRCMD); // send the write command with start condition
	out (address); // send address
	out (datum); // send data
	stop (); // send stop condition
}

void main(void)
{
    weeprom();

    // Insert code

    while(1)
        ;

}
