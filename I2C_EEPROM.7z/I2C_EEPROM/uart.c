#include "uart.h"
#include "mcs51/at89c51ed2.h"
#include <stdio.h>
#include <string.h>

extern uint16_t block;
extern uint16_t byte_addr;
extern uint16_t num;
extern uint16_t dat;

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* Name			- putchar()				                           */
/* Parameters	- int 					                           */
/* Return		- int 					                           */
/* Description	- This is the function that echos a character to   */
/* 				  the terminal.                                    */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
int putchar(int t)
{
    while(!TI);
    SBUF = t;
    TI = 0;
    return 1;
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* Name			- putchar()				                           */
/* Parameters	- int 					                           */
/* Return		- int 					                           */
/* Description	- This is the function that gets a character from  */
/* 				  the terminal.                                    */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
int getchar(void)
{
    while(!RI);
    RI = 0;
    return SBUF;
}

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* Name		    - getNum() 				   	                             */
/* Parameters	- void 						   	                         */
/* Return	    - uint8_t *						   	                     */
/* Description	- This is the function for getting numbers from user	 */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
uint8_t * getNum(uint16_t *address, uint16_t *mblock, uint16_t *sum)
{
    uint8_t buff[4] = {0};
    volatile uint8_t i = 0;
    uint8_t brk = 0;
    uint8_t temp;
    while(i < 4)
    {
        temp = getchar();
        if(i!=3)
        {
            printf_tiny("%c",temp);
        }
        if((i == 0) && (temp == 13))
        {
            printf_tiny("\n\rPlease enter a numeric value[in HEX] to continue, try again.\n\r");
            i=0;
            continue;
        }
        //tot_cnt++;
        if(((temp>47)&&(temp<58)||(temp>64)&&(temp<'G')||(temp<'g')&&(temp>96)) || (temp == 13))
        {
            buff[i] = temp;
            if(temp == 13)
            {
                break;
            }
            if(i == 3)
            {
                buff[i]=13;
            }
            i++;brk++;
        }
        else
        {
            num = 0;
            i=0;
            printf_tiny("\n\rEnter the size again in numbers[in HEX]:");
            memset(buff,0,sizeof(buff));
            brk=0;
        }
    }
    num = 0;
    uint8_t buffer[4] = {0};
    for(i = 0; i<3; i++)
    {
        if((buff[i]>47) && (buff[i]<58))
        {
            buffer[i] = buff[i] - 48;
        }
        if((buff[i]>64) && (buff[i]<71))
        {
            buffer[i] = buff[i] - 55;
        }
        if((buff[i]>96)&&(buff[i]<103))
        {
            buffer[i] = buff[i] - 87;
        }
        //printf_tiny("\n\rbuffer[%d]-->%d",i,buffer[i]);
    }

    {
        if((brk-1)<1)
        {
            num = buffer[0];
            *sum = num;
            //printf_tiny("\n\rbrk<1 and num -->%d\n\r",num);
            block = 0;
            byte_addr = buffer[0];
            //printf_tiny("\n\rbyte_address is--> %d",byte_addr);
        }
        else if((brk-1)<2)
        {
            num = (buffer[1]*1)+(buffer[0]*16);
            *sum = num;
            //printf_tiny("\n\rbrk<2 and num -->%d\n\r",num);
            block = 0;
            byte_addr = buffer[1]*1+(buffer[0]*16);
            //printf_tiny("\n\rbyte_address is--> %d",byte_addr);
        }
        else
        {
             num = (buffer[2]*1)+(buffer[1]*16)+(buffer[0]*256);
             *sum = num;
             //printf_tiny("\n\rbrk else and num -->%d\n\r",num);
             block = buffer[0];
             byte_addr = (buffer[2]*1)+(buffer[1]*16);
             //printf_tiny("\n\rbyte_address is-->%d",byte_addr);
        }
        //printf_tiny("\n\rcheck num-->%d",num);
    }

    printf_tiny("\n\rdec num-->%d\n\r",num);
    printf_tiny("\n\rhex num-->%x\n\r",num);
//    uint8_t hex[3];
//    sprintf(hex,"%x",num);
//    printf_tiny("\n\rprocessed hex-->%s",hex);
//    uint32_t val = atoi(hex);
//    printf_tiny("\n\ratoi val%d\n\r",val);
    if(num>2047)
    {
        printf_tiny("\n\rOut of scope value for memory allocation, try again.");
        //flag = 1;
    }
    else
    {
        //flag = 0;
        //printf_tiny("\n\rpage is-->%d",block);
        //printf_tiny("\n\rbyte_address is--> %d",byte_addr);
        *address = byte_addr;
        *mblock = block;
    }
    return buff;
}

uint8_t * getVal()
{
    uint8_t buff[3] = {0};
    volatile uint8_t i = 0;
    uint8_t brk = 0;
    uint8_t temp;
    while(i < 3)
    {
        temp = getchar();
        if(i!=2)
        {
            printf_tiny("%c",temp);
        }
        if((i == 0) && (temp == 13))
        {
            printf_tiny("\n\rPlease enter a numeric value[in HEX] to continue, try again.\n\r");
            i=0;
            continue;
        }
        //tot_cnt++;
        if(((temp>47)&&(temp<58)||(temp>64)&&(temp<'G')||(temp<'g')&&(temp>96)) || (temp == 13))
        {
            buff[i] = temp;
            if(temp == 13)
            {
                break;
            }
            if(i == 2)
            {
                buff[i]=13;
            }
            i++;brk++;
        }
        else
        {
            dat = 0;
            i=0;
            printf_tiny("\n\rEnter the size again in numbers[in HEX]:");
            memset(buff,0,sizeof(buff));
            brk=0;
        }
    }
    dat = 0;
    uint8_t buffer[3] = {0};
    for(i = 0; i<2; i++)
    {
        if((buff[i]>47) && (buff[i]<58))
        {
            buffer[i] = buff[i] - 48;
        }
        if((buff[i]>64) && (buff[i]<71))
        {
            buffer[i] = buff[i] - 55;
        }
        if((buff[i]>96)&&(buff[i]<103))
        {
            buffer[i] = buff[i] - 87;
        }
        //printf_tiny("\n\rbuffer[%d]-->%d",i,buffer[i]);
    }

    {
        if((brk-1)<1)
        {
            dat = buffer[0];
            //printf_tiny("\n\rbrk<1 and dat -->%d\n\r",dat);
            //block = 0;
            //byte_addr = buffer[0];
            //printf_tiny("\n\rbyte_address is--> %d",byte_addr);
        }
//        else if((brk-1)<2)
//        {
//            num = (buffer[1]*1)+(buffer[0]*16);
//            printf_tiny("\n\rbrk<2 and num -->%d\n\r",num);
//            block = 0;
//            byte_addr = buffer[1]*1+(buffer[0]*16);
//            //printf_tiny("\n\rbyte_address is--> %d",byte_addr);
//        }
        else
        {
             dat = /*(buffer[2]*1)+*/(buffer[1]*1)+(buffer[0]*16);
             //printf_tiny("\n\rbrk else and dat -->%d\n\r",dat);
             //block = buffer[0];
             //byte_addr = (buffer[2]*1)+(buffer[1]*16);
             //printf_tiny("\n\rbyte_address is-->%d",byte_addr);
        }
        //printf_tiny("\n\rcheck dat-->%d",dat);
    }

    printf_tiny("\n\rdec dat-->%d\n\r",dat);
    printf_tiny("\n\rhex dat-->%x\n\r",dat);
//    uint8_t hex[3];
//    sprintf(hex,"%x",num);
//    printf_tiny("\n\rprocessed hex-->%s",hex);
//    uint32_t val = atoi(hex);
//    printf_tiny("\n\ratoi val%d\n\r",val);
    if(dat>255)
    {
        printf_tiny("\n\rOut of scope value for data, try again.");
        //flag = 1;
    }
//    else
//    {
//        //flag = 0;
//        //printf_tiny("\n\rpage is-->%d",block);
//        //printf_tiny("\n\rbyte_address is--> %d",byte_addr);
//        //*address = byte_addr;
//        //*mblock = block;
//    }
    return buff;
}
