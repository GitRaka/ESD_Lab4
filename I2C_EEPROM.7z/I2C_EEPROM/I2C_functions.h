#include "mcs51/at89c51ed2.h"
#include <stdio.h>
#include "stdint.h"
#define SDA (P1_6)
#define SCK (P1_7)
void weeprom (char page, char address, char datum);
char reeprom (char page, char address);
char read (char readcmd);
void outs (char datum);
void out (char datum);
char in (void);
void stop (void);
void start(void);
void eereset();
void Seq_read(char page,uint16_t faddress,uint16_t sum1, uint16_t sum2);
