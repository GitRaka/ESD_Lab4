//**********************************************************************
//* Function Name: void weeprom (char page, char address, char datum)
//**********************************************************************
//* Function Description: write routine for I2C EEPROM
//**********************************************************************
//* Input parameters:
//* - char page: number of 256 bytes block to use
//* - char address: position inside the 256 bytes block
//* - char datum: 1 byte data to write
//**********************************************************************
//* Output parameters: NONE
//**********************************************************************
/// Notes: NONE
//**********************************************************************
#include "main.h"
#include "mcs51/at89c51ed2.h"
#include <stdio.h>
#include <string.h>
#include "uart.h"
#include "I2C_functions.h"
uint16_t num;
uint16_t dat;
uint16_t block;
uint16_t byte_addr;
uint16_t iaddress;
uint16_t eaddress;
uint16_t iblock;
uint16_t eblock;
uint16_t isum;
uint16_t esum;

void delay(uint16_t val);
uint8_t welcome_user();
void write();
void readm();

//the main function to do function calls
void main()
{
    uint16_t exit = 1;
    while(exit)
    {
        uint8_t input = welcome_user();
        switch(input)
        {
            case '1':
                    write();
                    break;
            case '2':
                    readm();
                    break;
            case '3':
                    printf_tiny("\n\rEnter the address to start read from:\n\r");
                    getNum(&iaddress,&iblock,&isum);
                    printf_tiny("\n\rEnter the address to end read to:\n\r");
                    getNum(&eaddress,&eblock,&esum);
                    Seq_read(iblock,iaddress,isum,esum);
                    break;
            case '4':
                    printf_tiny("\n\rResetting the I2C bus.......\n\r");
                    delay(50000);
                    eereset();
                    break;
            case '5':
                    exit = 0;
                    printf_tiny("\n\rExiting the program.\n\r");
                    delay(50000);
                    printf_tiny("\n\r\n\rExited.\n\r");
                    __asm
                    ljmp 0000
                    __endasm;
                    break;
        }
    }
}



//delay function for proper synchronization
void delay(uint16_t val)
{
    while(val>0)
    {
        val--;
    }
}

uint8_t welcome_user()
{
    printf_tiny("\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\r");
    printf_tiny("~~~~~~~~~~~~~~~~~~~~~~I2C Prototype Implementation~~~~~~~~~~~~~~~~~~~~~~~~\n\r");
    printf_tiny("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\r\n\r");
    printf_tiny("Please choose from the below options to proceed\n\r");
    printf_tiny("1. Write Byte.\n\r");
    printf_tiny("2. Read Byte.\n\r");
    printf_tiny("3. Hex Dump\n\r");
    printf_tiny("4. Reset EEPROM\n\r");
    printf_tiny("5. Exit\n\r");
    uint8_t recv = getchar();
    printf_tiny("\n\rEntered Choice: %c",recv);
    return recv;
}

void readm()
{
    printf_tiny("\n\rEnter the address to read from:\n\r");
    getNum(&byte_addr,&block,&isum);
    char temp = reeprom(block,byte_addr);
    printf_tiny("\n\rThe value at block: %d and page address: 0x%x  is: 0x%x\n\r",block,byte_addr,temp);
    byte_addr = 0;block = 0;
}

void write()
{
    printf_tiny("\n\rPlease enter address to write to:");
    getNum(&byte_addr,&block,&isum);
    printf_tiny("\n\rEnter the data to be entered to the specified address:");
    getVal();
    weeprom(block,byte_addr,dat);
    delay(1000);
}


