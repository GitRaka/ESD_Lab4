#include <stdint.h>

int putchar(int t);
int getchar(void);
uint8_t * getNum(uint16_t *address, uint16_t *block, uint16_t *sum);
uint8_t * getVal();

